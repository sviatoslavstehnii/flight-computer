// server.js
const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');

const wss = new WebSocket.Server({ port: 8080 });
const file = path.join(__dirname, 'data.txt');

let lines = [];
let currentLine = 0;

try {
  const data = fs.readFileSync(file, 'utf8');
  lines = data.split('\n').filter((line) => line.trim() !== '');
} catch (err) {
  console.error(`Error reading data file: ${err}`);
}

wss.on('connection', (ws) => {
  console.log('Client connected');

  const sendData = () => {
    if (currentLine >= lines.length) {
      currentLine = 0; // Reset to loop the data
    }

    const line = lines[currentLine];
    currentLine++;

    const att = parseLine(line);

    const data = {
      latitude: getRandomInRange(-90, 90, 6),
      longitude: getRandomInRange(-180, 180, 6),
      height: getRandomInRange(0, 10000, 2),
      roll: att.roll,
      pitch: att.pitch,
      yaw: att.yaw,
    };

    ws.send(JSON.stringify(data));
  };

  const interval = setInterval(sendData, 1000);

  ws.on('close', () => {
    console.log('Client disconnected');
    clearInterval(interval);
  });
});

function parseLine(line) {
  const att = { roll: 0, pitch: 0, yaw: 0 };
  const parts = line.split(',');
  parts.forEach((part) => {
    const [key, value] = part.split(':').map((str) => str.trim());
    if (key && value) {
      att[key.toLowerCase()] = parseFloat(value) * (Math.PI / 180); // Convert to radians
    }
  });
  return att;
}

function getRandomInRange(min, max, decimals) {
  const num = Math.random() * (max - min) + min;
  return parseFloat(num.toFixed(decimals));
}

console.log('WebSocket server is running on ws://localhost:8080');