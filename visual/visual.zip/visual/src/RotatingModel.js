// RotatingModel.js
import React, { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { useGLTF } from "@react-three/drei";



export default function RotatingModel({ eulerAngles }) {
  const cubeRef = useRef();
  const { nodes } = useGLTF("/model.glb");
  

  useFrame(() => {
    if (cubeRef.current) {
      cubeRef.current.rotation.x = eulerAngles.x;
      cubeRef.current.rotation.y = eulerAngles.y;
      cubeRef.current.rotation.z = eulerAngles.z;
    }
  });

  return (
    <mesh ref={cubeRef} position={[0, 0, 0]}>
      <boxGeometry args={[.6, 2, 1]} />
      <meshStandardMaterial color="orange" />
    </mesh>
  );
}

