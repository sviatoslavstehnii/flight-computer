import serial
import time
ser = serial.Serial("/dev/ttyUSB0", 115200, timeout=1)

ser.write(b'DEB0\r\n')
time.sleep(1)

for i in range(10):
    ser.write(b"hello" + str(i).encode() + b"\r\n")
    time.sleep(.3)