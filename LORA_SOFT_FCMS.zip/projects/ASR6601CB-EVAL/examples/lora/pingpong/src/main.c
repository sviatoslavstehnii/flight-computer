#if 1

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>
#undef errno
extern int errno;

extern char _end; // Defined by the linker script
static char* heap_end;

caddr_t _sbrk(int incr)
{
    if (heap_end == 0) {
        heap_end = &_end;
    }
    char* prev_heap_end = heap_end;
    heap_end += incr;
    return (caddr_t)prev_heap_end;
}

int _open(const char* name, int flags, int mode) { return -1; }
int _close(int file) { return -1; }
int _fstat(int file, struct stat* st) { return 0; }
int _lseek(int file, int ptr, int dir) { return 0; }
int _read(int file, char* ptr, int len) { return 0; }
int _write(int file, char* ptr, int len) { return 0; }
int _isatty(int file) { return 1; }

// ----------------------------------------------------------

#include "delay.h"
#include "timer.h"
#include "radio.h"
#include "tremo_system.h"
#include "tremo_uart.h"
#include "tremo_gpio.h"
#include "tremo_rcc.h"
#include "tremo_pwr.h"
#include "tremo_delay.h"
#include "rtc-board.h"

#define RF_FREQUENCY        915000000
#define TX_OUTPUT_POWER     14
#define LORA_BANDWIDTH      0
#define LORA_SPREADING_FACTOR  7
#define LORA_CODINGRATE     1
#define LORA_PREAMBLE_LENGTH  8
#define LORA_SYMBOL_TIMEOUT   0
#define LORA_FIX_LENGTH_PAYLOAD_ON false
#define LORA_IQ_INVERSION_ON  false

typedef enum
{
    LOWPOWER,
    RX,
    RX_TIMEOUT,
    RX_ERROR,
    TX,
    TX_TIMEOUT
} States_t;

#define RX_TIMEOUT_VALUE 5000
#define BUFFER_MAX_SIZE  128

uint16_t BufferSize = 0;
uint8_t  Buffer[BUFFER_MAX_SIZE];
int8_t   RssiValue = 0;
int8_t   SnrValue  = 0;
uint32_t ChipId[2] = {0};
volatile States_t State = LOWPOWER;

typedef struct
{
    uint8_t* payload;
    uint16_t length;
    uint8_t  checksum;
} LoRaPacket_t;

static RadioEvents_t RadioEvents;
static bool isMaster = true;
static bool debug = false;

void OnTxDone(void);
void OnRxDone(uint8_t* payload, uint16_t size, int16_t rssi, int8_t snr);
void OnTxTimeout(void);
void OnRxTimeout(void);
void OnRxError(void);

// Minimal helper to check UART input
static bool isUartDataAvailable(void)
{
    return !uart_get_flag_status(CONFIG_DEBUG_UART, UART_FLAG_RX_FIFO_EMPTY);
}

// Reads up to (maxLen-1) chars or until newline
static int readUartLine(char* buffer, int maxLen)
{
    int idx = 0;
    while(idx < (maxLen - 1))
    {
        // Wait until data is available
        if(!isUartDataAvailable()){

        }
        buffer[idx] = uart_receive_data(CONFIG_DEBUG_UART);
        // Stop at newline
        if(buffer[idx] == '\r' || buffer[idx] == '\n')
            break;
        idx++;
    }
    buffer[idx] = '\0';
    return idx;
}

void sendUartMessage(const char* msg)
{
    LoRaPacket_t packet;
    uint16_t size = strlen(msg);
    if(size > BUFFER_MAX_SIZE) size = BUFFER_MAX_SIZE;

    packet.length  = size;
    packet.payload = malloc(size);
    memcpy(packet.payload, msg, size);
    packet.checksum = 0;

    BufferSize = packet.length;
    memcpy(Buffer, packet.payload, BufferSize);
    free(packet.payload);

    Radio.Send(Buffer, BufferSize);
    if (debug)  printf("Sent: %s\r\n", msg);
}

int app_start(void)
{
    printf("UART-based LoRa sender.\r\n");
    system_get_chip_id(ChipId);

    RadioEvents.TxDone    = OnTxDone;
    RadioEvents.RxDone    = OnRxDone;
    RadioEvents.TxTimeout = OnTxTimeout;
    RadioEvents.RxTimeout = OnRxTimeout;
    RadioEvents.RxError   = OnRxError;

    Radio.Init(&RadioEvents);
    Radio.SetChannel(RF_FREQUENCY);

    Radio.SetTxConfig(
        MODEM_LORA, TX_OUTPUT_POWER, 0, LORA_BANDWIDTH,
        LORA_SPREADING_FACTOR, LORA_CODINGRATE,
        LORA_PREAMBLE_LENGTH, LORA_FIX_LENGTH_PAYLOAD_ON,
        true, 0, 0, LORA_IQ_INVERSION_ON, 5000
    );

    Radio.SetRxConfig(
        MODEM_LORA, LORA_BANDWIDTH, LORA_SPREADING_FACTOR,
        LORA_CODINGRATE, 0, LORA_PREAMBLE_LENGTH,
        LORA_SYMBOL_TIMEOUT, LORA_FIX_LENGTH_PAYLOAD_ON,
        0, true, 0, 0, LORA_IQ_INVERSION_ON, true
    );

    Radio.Rx(RX_TIMEOUT_VALUE);

    char uartBuffer[BUFFER_MAX_SIZE];
    while(1)
    {
        // If user typed something via UART
        if(isUartDataAvailable())
        {
            int len = readUartLine(uartBuffer, BUFFER_MAX_SIZE);
            if(len > 0)
            {
                sendUartMessage(uartBuffer);
            }
        }

        switch(State)
        {
        case RX:
            if(BufferSize > 0)
            {
                if (strncmp((const char*)Buffer, "DEB1", 4) == 0)
                {
                    debug = true;
                    printf("Debug mode: %s\r\n", debug ? "ON" : "OFF");
                }
                else if (strncmp((const char*)Buffer, "DEB0", 4) == 0)
                {
                    debug = false;
                    printf("Debug mode: %s\r\n", debug ? "ON" : "OFF");
                }
                else
                {
                    // printf("Received: %.*s\r\n", BufferSize, Buffer);
                    if (debug) printf("Received: %.*s\r\n", BufferSize, Buffer);
                    else printf("%.*s\r\n", BufferSize, Buffer);
                }
                
                // printf("Received: %.*s\r\n", BufferSize, Buffer);
                // if (debug) printf("Received: %.*s\r\n", BufferSize, Buffer);
                // else printf("%.*s\r\n", BufferSize, Buffer);
            }
            Radio.Rx(RX_TIMEOUT_VALUE);
            State = LOWPOWER;
            break;

        case TX:
            Radio.Rx(RX_TIMEOUT_VALUE);
            State = LOWPOWER;
            break;

        case RX_TIMEOUT:
        case RX_ERROR:
            if(isMaster)
            {
                // Just stay in receive mode
            }
            Radio.Rx(RX_TIMEOUT_VALUE);
            State = LOWPOWER;
            break;

        case TX_TIMEOUT:
            Radio.Rx(RX_TIMEOUT_VALUE);
            State = LOWPOWER;
            break;

        case LOWPOWER:
        default:
            break;
        }
        Radio.IrqProcess();
    }
}

void OnTxDone(void)
{
    if (debug) printf("OnTxDone\r\n");
    // Radio.Sleep();
    State = TX;
}

void OnRxDone(uint8_t* payload, uint16_t size, int16_t rssi, int8_t snr)
{
    if (debug) printf("onRxDone\r\n");
    // Radio.Sleep();
    
    BufferSize = size;
    memcpy(Buffer, payload, BufferSize);

    RssiValue = rssi;
    SnrValue  = snr;
    State = RX;
}

void OnTxTimeout(void)
{
    if (debug)
        printf("OnTxTimeout\r\n");
    Radio.Sleep();
    State = TX_TIMEOUT;
}

void OnRxTimeout(void)
{
    if (debug)
        printf("OnRxTimeout\r\n");
    Radio.Sleep();
    State = RX_TIMEOUT;
}

void OnRxError(void)
{
    printf("OnRxError\r\n");
    Radio.Sleep();
    State = RX_ERROR;
}

// Basic board init
void uart_log_init(void)
{
    gpio_set_iomux(GPIOB, GPIO_PIN_0, 1);
    gpio_set_iomux(GPIOB, GPIO_PIN_1, 1);
    uart_config_t uart_config;
    uart_config_init(&uart_config);
    uart_config.baudrate = UART_BAUDRATE_115200;
    uart_init(CONFIG_DEBUG_UART, &uart_config);
    uart_cmd(CONFIG_DEBUG_UART, ENABLE);
}

void board_init()
{
    rcc_enable_oscillator(RCC_OSC_XO32K, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_UART0, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_GPIOA, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_GPIOB, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_GPIOC, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_GPIOD, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_PWR, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_RTC, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_SAC, true);
    rcc_enable_peripheral_clk(RCC_PERIPHERAL_LORA, true);
    delay_ms(1000);
    pwr_xo32k_lpm_cmd(true);
    uart_log_init();
    RtcInit();
}

int main(void)
{
    printf("ASR6601CB-EVAL board init start!\r\n");
    board_init();
    app_start();
}

#endif
