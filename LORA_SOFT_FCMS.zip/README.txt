1.Clone the repo https://github.com/Ai-Thinker-Open/Ai-Thinker-LoRaWAN-Ra-08

2.Build following the instructions (using ports RXD0 and TXD)

3.Replace the "projects" dir with the content of this ZIP

4. The lora software is in the "/ASR6601CB-EVAL/examples/lora/pingpong/main.c" subdir

5. To enter program mode pull the IO2 pin on lora high and while it is high, pull the RST pin low so that lora reboots in the program mode. After programming reboot again.

6. Remember to set baud rate the same as in the program to monitor the serial port (default is 115200)
